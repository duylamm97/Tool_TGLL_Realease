@echo off
start "" "%~dp0Tool_TGLL_Auto.exe"
